/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'de', {
	alt: 'Alternativer Text',
	btnUpload: 'Zum Server senden',
	captioned: 'Bild mit Überschrift',
	captionPlaceholder: 'Überschrift',
	infoTab: 'Bildinfo',
	lockRatio: 'Größenverhältnis beibehalten',
	menu: 'Bildeigenschaften',
	pathName: 'Bild',
	pathNameCaption: 'Überschrift',
	resetSize: 'Größe zurücksetzen',
	resizer: 'Zum Vergrößern auswählen und ziehen',
	title: 'Bild-Eigenschaften',
	uploadTab: 'Hochladen',
	urlMissing: 'Bildquellen-URL fehlt.',
	altMissing: 'Alternativer Text fehlt.'
} );
