/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'sl', {
	alt: 'Nadomestno besedilo',
	btnUpload: 'Pošlji na strežnik',
	captioned: 'Slika z napisom',
	captionPlaceholder: 'Napis',
	infoTab: 'Podatki o sliki',
	lockRatio: 'Zakleni razmerje',
	menu: 'Lastnosti slike',
	pathName: 'slika',
	pathNameCaption: 'napis',
	resetSize: 'Ponastavi velikost',
	resizer: 'Kliknite in povlecite, da spremenite velikost',
	title: 'Lastnosti slike',
	uploadTab: 'Naloži',
	urlMissing: 'Manjka vir (URL) slike.',
	altMissing: 'Alternative text is missing.' // MISSING
} );
